export const ADD_MUSIC = "ADD_MUSIC";
export const SELECTED_MUSIC = "SELECTED_MUSIC";
