import MUSIC_ICON from "../../src/assets/icon/music-icon.png";

export {
  MUSIC_ICON,
}